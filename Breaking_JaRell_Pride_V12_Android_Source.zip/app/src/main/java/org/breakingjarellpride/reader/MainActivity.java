package org.breakingjarellpride.reader;
import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import java.io.InputStream;
import java.util.Locale;

public class MainActivity extends Activity {
 private WebView web;
 private static final String HOST="appassets.androidplatform.net";
 @Override public void onCreate(Bundle b){super.onCreate(b);
  web=new WebView(this);setContentView(web);
  WebSettings settings=web.getSettings();settings.setJavaScriptEnabled(true);settings.setDomStorageEnabled(true);
  settings.setAllowFileAccess(false);settings.setAllowContentAccess(false);
  web.setWebChromeClient(new WebChromeClient());
  web.setWebViewClient(new WebViewClient(){
   @Override public WebResourceResponse shouldInterceptRequest(WebView view,WebResourceRequest req){
    Uri u=req.getUrl(); if(!"https".equals(u.getScheme())||!HOST.equals(u.getHost()))return null;
    String path=u.getPath();if(path==null||!path.startsWith("/assets/"))return new WebResourceResponse("text/plain","UTF-8",404,"Not Found",java.util.Collections.emptyMap(),new java.io.ByteArrayInputStream(new byte[0]));
    String name=path.substring(8);if(name.contains("..")||name.contains("/")||name.isEmpty())return null;
    String mime=name.endsWith(".js")?"application/javascript":name.endsWith(".json")||name.endsWith(".webmanifest")?"application/json":name.endsWith(".html")?"text/html":"text/plain";
    try{InputStream stream=getAssets().open(name);return new WebResourceResponse(mime,"UTF-8",stream);}catch(Exception e){return null;}
   }
   @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest req){Uri u=req.getUrl();if("https".equals(u.getScheme())&&HOST.equals(u.getHost()))return false;
    if("https".equals(u.getScheme())||"http".equals(u.getScheme())||"geo".equals(u.getScheme())){try{startActivity(new Intent(Intent.ACTION_VIEW,u));}catch(Exception ignored){}return true;}return true;
   }
  });
  web.loadUrl("https://"+HOST+"/assets/index.html");
 }
 @Override public void onBackPressed(){if(web!=null&&web.canGoBack())web.goBack();else super.onBackPressed();}
 @Override protected void onDestroy(){if(web!=null)web.destroy();super.onDestroy();}
}
