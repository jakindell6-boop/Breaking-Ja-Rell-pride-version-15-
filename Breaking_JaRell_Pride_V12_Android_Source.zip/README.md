# Breaking Ja’Rell Pride — Android project (Version 12)

This is an Android project, **not a compiled APK**. Version 12 is the source version; the app version shown to Android is 1.2.0. The included GitHub Actions workflow builds a debug APK when you push to `main` or run it manually from the repository's **Actions** tab. Download the `Breaking-JaRell-Pride-debug-APK` artifact from the completed run. You can also open the folder in Android Studio (JDK 17, Android SDK 35) and select **Build > Build APK(s)**; the debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

The local book reader and progress use bundled assets and WebView storage. Bible Gateway, Ethiopian references, and locator searches require Internet. External links now route to the device browser. Marriage is informational only; no accounts, messaging, or age verification exist.


## Scripture library update (v4)
Added Ancient Texts tab with Torah, 1 Enoch, Ethiopian canon, Dead Sea Scrolls and 11Q13 Melchizedek reference links, plus persistent preferred-language entry. These are curated external reading references, **not embedded complete texts** or machine translations. Language coverage is aspirational. Do not claim an APK was compiled.

## Kingdom Careers integration (v5)
A **Jobs** tab opens the externally hosted Kingdom Careers website in the device browser. Set `KINGDOM_CAREERS_URL` in `app/src/main/assets/app.js` to your actual HTTPS host before compiling. The starter web app, Supabase schema and deployment instructions are in the companion `Kingdom_Careers_Starter.zip`. **No live backend, listings, or APK is bundled.**


Version 6: Added author-approved hope reflection and original Selah psalm immediately after Pride/Humility in the manuscript reader; cross-reference Road to Recovery. No compiled APK.


Version 8: expanded Scripture-wide reference with 197 names, titles, images, and descriptions; each entry has meaning/context and references. This is not a claim of an exhaustive list of every descriptive phrase in every Bible translation.

Version 12 / app 1.2.0: the Books filter includes **The First Gospel of the Infancy of Jesus Christ** (also called the Infancy Gospel of Thomas), with an external reading link to a public-domain English edition. The incorrect Embassy of Jesus Christ entry has been removed. Kingdom Careers includes a temporary-work locator that searches external Google Search and Maps results using a city or ZIP entered by the user; it does not request device location or verify listings. This package is Android source, not a compiled APK.

Kingdom Fitness Training (app 1.2.0): the app presents the user-provided peek-a-boo boxing to BJJ training pathway and provides external Google Search/Maps gym locators. The locator does not confirm a gym offers this exact coaching; contact gyms directly.
