# Kingdom Careers global jobs API starter

The Android app expects a read-only endpoint at `GET {CAREERS_API_URL}/v1/jobs` with query parameters `city`, `country`, and optional `type`. The response is JSON with a top-level `jobs` array. Each record may include `title`, `employer`, `city`, `region`, `country_name`, `country_code`, `description`, `apply_url`, `source_url`, and `verification_status`.

Requirements before connecting a live provider:

- Host the API over HTTPS and allow CORS from the app's `https://appassets.androidplatform.net` origin.
- Return only published, unexpired listings and escape/sanitize provider data.
- Label employer verification accurately; do not treat search-engine results as verified vacancies.
- Keep posting, employer verification, moderation, and credentials on the server. Never place service-role secrets in the Android app.
- Set `KINGDOM_CAREERS_API_URL` in `app/src/main/assets/app.js` to the deployed endpoint.

The included SQL is a starter schema only. No live database, provider integration, employer accounts, or listings are included in this source package.
