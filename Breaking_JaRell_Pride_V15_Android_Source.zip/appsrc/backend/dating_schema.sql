-- Kingdom Dating starter schema. This is not a deployed service.
-- Create only after selecting an authentication provider and implementing server-side age checks.
CREATE TABLE dating_profiles (
  id UUID PRIMARY KEY,
  account_id UUID NOT NULL UNIQUE,
  display_name VARCHAR(60) NOT NULL,
  country_code CHAR(2) NOT NULL,
  region VARCHAR(120),
  about_marriage VARCHAR(500),
  age_verified_at TIMESTAMPTZ NOT NULL,
  age_verification_method VARCHAR(40) NOT NULL,
  profile_status VARCHAR(20) NOT NULL DEFAULT 'draft'
    CHECK (profile_status IN ('draft','pending_review','active','paused','removed')),
  visibility VARCHAR(20) NOT NULL DEFAULT 'private'
    CHECK (visibility IN ('private','members_only')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  deleted_at TIMESTAMPTZ
);

CREATE TABLE dating_blocks (
  blocker_account_id UUID NOT NULL,
  blocked_account_id UUID NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (blocker_account_id, blocked_account_id),
  CHECK (blocker_account_id <> blocked_account_id)
);

CREATE TABLE dating_reports (
  id UUID PRIMARY KEY,
  reporter_account_id UUID NOT NULL,
  reported_account_id UUID NOT NULL,
  reason_code VARCHAR(40) NOT NULL,
  details VARCHAR(2000),
  status VARCHAR(20) NOT NULL DEFAULT 'open'
    CHECK (status IN ('open','reviewing','resolved','dismissed')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (reporter_account_id <> reported_account_id)
);

-- Production requirements: enforce account ownership and row-level access on the server;
-- never trust an age checkbox or client-supplied age_verified_at. Do not store precise GPS,
-- birth dates, or sensitive documents unless strictly necessary and protected by a reviewed
-- verification provider. Search only active, reviewed, opted-in profiles. Keep reports private.
