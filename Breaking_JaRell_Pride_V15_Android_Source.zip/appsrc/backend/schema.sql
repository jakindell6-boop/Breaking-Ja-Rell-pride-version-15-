-- PostgreSQL starter schema for Kingdom Careers international listings.
-- Apply only to a project you own; this does not create or host a live database.
create extension if not exists pgcrypto;

create table if not exists employers (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  website_url text,
  country_code char(2) not null,
  verification_status text not null default 'pending' check (verification_status in ('pending','verified','rejected')),
  created_at timestamptz not null default now()
);

create table if not exists job_listings (
  id uuid primary key default gen_random_uuid(),
  employer_id uuid references employers(id) on delete set null,
  title text not null,
  description text not null default '',
  city text not null,
  region text,
  country_code char(2) not null,
  country_name text not null,
  language_code text not null default 'en',
  employment_type text not null check (employment_type in ('temporary','seasonal','contract','permanent','apprenticeship','internship')),
  source_url text,
  apply_url text,
  salary_min numeric,
  salary_max numeric,
  salary_currency char(3),
  verification_status text not null default 'unverified' check (verification_status in ('unverified','pending','verified','rejected')),
  status text not null default 'draft' check (status in ('draft','published','closed')),
  published_at timestamptz,
  expires_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists job_listings_search_idx on job_listings(country_code, region, city, employment_type, status, expires_at);
create index if not exists job_listings_published_idx on job_listings(published_at desc) where status = 'published';

-- Public app access should be read-only and limited to published, unexpired listings.
-- Employer posting, identity checks, moderation, and admin access require authenticated server-side policies.
