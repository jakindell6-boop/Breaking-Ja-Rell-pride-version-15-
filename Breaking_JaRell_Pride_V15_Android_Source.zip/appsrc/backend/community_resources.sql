-- Public community-resource directory starter; no member personal data belongs in this table.
CREATE TABLE community_resources (
  id UUID PRIMARY KEY,
  name VARCHAR(180) NOT NULL,
  category VARCHAR(32) NOT NULL CHECK (category IN (
    'food_support','recovery','trade_training','employment','housing','community_nonprofit'
  )),
  country_code CHAR(2) NOT NULL,
  city VARCHAR(120) NOT NULL,
  region VARCHAR(120),
  service_description VARCHAR(3000) NOT NULL,
  training_areas TEXT[] NOT NULL DEFAULT '{}',
  language_codes TEXT[] NOT NULL DEFAULT '{}',
  eligibility VARCHAR(1500),
  fee_information VARCHAR(500),
  contact_url TEXT,
  source_url TEXT NOT NULL,
  verification_status VARCHAR(20) NOT NULL DEFAULT 'pending'
    CHECK (verification_status IN ('pending','verified','needs_review','closed')),
  last_verified_at TIMESTAMPTZ,
  review_due_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX community_resources_place_category
  ON community_resources(country_code, city, category, verification_status);

-- Publish only active resources with a recent verification. Recheck contact details,
-- hours, fees, eligibility, and whether each program still accepts participants.
