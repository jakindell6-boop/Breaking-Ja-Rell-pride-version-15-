# Community resource directory API starter

The app's live locator currently sends user-entered city/region, country, and selected resource category to Google Search or Maps. Those results are external and not verified by the app. This contract describes an optional first-party directory; no endpoint or resource database is deployed.

## Search

`GET /v1/resources?city=Houston&country=US&category=trade_training&training_area=welding`

Return a `resources` array with name, category, city, region, country, description, training areas, language support, eligibility, fee information, contact URL, source URL, verification status, and last-verified date. Only publish active, recently reviewed listings. Support food support, recovery, trade training, workforce/employment, housing, and community nonprofit categories.

## Data and review requirements

Keep listings about organizations and programs, not people seeking help. Use HTTPS, sanitize output, rate-limit requests, record sources and review dates, and provide a way to report closed or incorrect listings. Confirm service details with the organization before labeling a listing verified. Provide country/region filters and avoid device location collection. The included SQL is a schema starter, not a populated or maintained global database.
