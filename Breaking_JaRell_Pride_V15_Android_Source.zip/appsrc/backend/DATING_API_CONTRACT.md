# Kingdom Dating API starter

This contract is a deployment plan only. The app currently has no dating accounts, public profiles, matching, or messaging backend. The in-app profile draft is stored locally on the user's device and is not uploaded.

## Minimum service routes

- `POST /v1/age-verification/sessions` — start a server-side adult eligibility check with a vetted provider; do not treat a client checkbox as verification.
- `POST /v1/dating/profile` — create or update an authenticated user's draft profile after adult verification.
- `POST /v1/dating/profile/publish` — publish only after explicit opt-in and moderation; default visibility stays private.
- `GET /v1/dating/profiles?country=US&region=...` — return only opted-in, active profiles. Never expose email, exact address, verification records, or report history.
- `POST /v1/dating/blocks` and `POST /v1/dating/reports` — block accounts and submit private safety reports.
- `DELETE /v1/dating/profile` — remove the profile and queue account data deletion.

## Required safeguards before launch

Use HTTPS, authenticated sessions, server-side adult verification, abuse rate limits, moderation, blocking/reporting, data export/deletion, privacy-by-default, and a documented retention policy. Do not permit minors to register or appear in search. Use coarse user-entered country/region only; do not request continuous device location. Do not launch messaging until moderation and safety operations are staffed. Local laws and platform requirements must be reviewed for every launch country.

This starter does not implement or host those controls. Do not point the app at an unreviewed public database.
