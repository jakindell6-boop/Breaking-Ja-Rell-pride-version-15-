# Breaking Ja’Rell Pride — Android project (Source Version 15)

This is an Android project, **not a compiled APK**. Version 14 is the current source release; the app version shown to Android is 1.2.0 (versionCode 14). The included GitHub Actions workflow builds a debug APK when you push to `main` or run it manually from the repository's **Actions** tab. Download the `Breaking-JaRell-Pride-debug-APK` artifact from the completed run. You can also open the folder in Android Studio (JDK 17, Android SDK 35) and select **Build > Build APK(s)**; the debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

The 50-section reader, 66-book selector, and app interface are bundled in Android assets; the reader works offline after installation. Scripture and ancient-book links, as well as job, gym, church, and aid locators, need Internet. Locator searches use the entered city/region and country, open external Google Search or Maps, and are not verified by this app. Kingdom Careers has an API client and database schema starter, but no live listings service is connected. The language selector offers partial English, Spanish, Tagalog, and Hebrew UI translations. See GLOBAL_READINESS.md for country-by-country deployment limits. External links route to the device browser. Marriage & Family remains informational. Kingdom Dating now provides a private, on-device profile draft, but no public accounts, matching, messaging, or verified-age service is active.


## Scripture library update (v4)
Added Ancient Texts tab with Torah, 1 Enoch, Ethiopian canon, Dead Sea Scrolls and 11Q13 Melchizedek reference links, plus persistent preferred-language entry. These are curated external reading references, **not embedded complete texts** or machine translations. Language coverage is aspirational. Do not claim an APK was compiled.

## Kingdom Careers integration (v5)
A **Jobs** tab opens the externally hosted Kingdom Careers website in the device browser. Set `KINGDOM_CAREERS_URL` in `app/src/main/assets/app.js` to your actual HTTPS host before compiling. The starter web app, Supabase schema and deployment instructions are in the companion `Kingdom_Careers_Starter.zip`. **No live backend, listings, or APK is bundled.**


Version 6: Added author-approved hope reflection and original Selah psalm immediately after Pride/Humility in the manuscript reader; cross-reference Road to Recovery. No compiled APK.


Version 8: expanded Scripture-wide reference with 197 names, titles, images, and descriptions; each entry has meaning/context and references. This is not a claim of an exhaustive list of every descriptive phrase in every Bible translation.

Version 12 / app 1.2.0: the Books filter includes **The First Gospel of the Infancy of Jesus Christ** (also called the Infancy Gospel of Thomas), with an external reading link to a public-domain English edition. The incorrect Embassy of Jesus Christ entry has been removed. Kingdom Careers includes a temporary-work locator that searches external Google Search and Maps results using a city or ZIP entered by the user; it does not request device location or verify listings. This package is Android source, not a compiled APK.

Kingdom Fitness Training (app 1.2.0): the app presents the user-provided peek-a-boo boxing to BJJ training pathway and provides external Google Search/Maps gym locators. The locator does not confirm a gym offers this exact coaching; contact gyms directly.


Community Resources (app 1.2.0): country-aware Google Search/Maps searches now cover food support, recovery centers, nonprofit trade training, employment/workforce services, housing, and community nonprofits. Trade filters include welding, plumbing, electrical, construction, CDL, heavy equipment, healthcare, teaching, and language classes. U.S.-only 211 and Feeding America links are labeled. Search results are external and unverified; the resource SQL/API files are starters only.

Kingdom Dating (app 1.2.0): marriage-intent page for unmarried adults 18+. A private introduction draft can be saved on the device only. No profiles are published and there are no matches or messages. `backend/dating_schema.sql` and `backend/DATING_API_CONTRACT.md` describe the service work required before real membership opens. The Android version code is 13 so this source can upgrade prior code 12 builds while continuing to display version 1.2.0.
